#include "tree.h"

int serial = 0;

struct tree *link_tree(int prodrule, char *symbolname, int nkids, ...) {
    va_list arg;
    va_start(arg, nkids);

    struct tree *linked_tree = create_tree();

    linked_tree->prodrule = prodrule;
    linked_tree->symbolname = symbolname;
    linked_tree->nkids = nkids;
    linked_tree->id = serial++;

    for(int i = 0; i < nkids; i++){
        linked_tree->kids[i] = va_arg(arg, struct tree *);
        linked_tree->kids[i]->id = serial++;
        //printf("Made into kids loop!");
    }

    va_end(arg);

    return linked_tree;
}

struct tree *create_tree() {
    struct tree *new_tree = malloc(sizeof(struct tree));
    memset(new_tree, 0, sizeof(struct tree));
    return new_tree;
}

void free_tree(struct tree *root){
    if(root == NULL)
        return;
    for(int i = 0; i < 9; i++){
        free_tree(root->kids[i]);
    }

    if(root->leaf != NULL){
        free(root->leaf->text);
        if(root->leaf->sval != NULL){
            free(root->leaf->sval);
        }
        free(root->leaf);
    }

    free(root);
}

int print_tree(struct tree *root, int depth) {
    int i;
    if(root == NULL){
        //printf("Node is null!");
        return 1;
    }
    if (root->prodrule == TOKEN){
        printf("%*s %s %d: %s\n", depth*4, " ", root->symbolname, root->leaf->category, root->leaf->text);
    } else {
        printf("%*s %s: %d\n", depth*4, " ", root->symbolname, root->nkids);
    }

    for(i=0; i < root->nkids; i++){
        print_tree(root->kids[i], depth+1);
    }

    return 0;
}

void print_graph(struct tree *root, char *filename) {
	FILE *fp = NULL;
	char *dotfile = NULL;
	dotfile = strdup(filename);
	strcat(dotfile, ".dot");
	fp = fopen(dotfile, "w");
	fprintf(fp, "digraph {\n");
	print_graph_node(root, fp);
	fprintf(fp, "}");
	free(dotfile);
}

int print_graph_node(struct tree *node, FILE *fp){
	if(node == NULL){
        //printf("Node is null!");
        return 1;
    }
    int i;
    
    if (node->prodrule == TOKEN){
        fprintf(fp, "\t%d [label=\"%s\"]\n", node->id, node->leaf->text);
        printf("id=%d: symbolname=%s: lexeme=%s\n", node->id, node->symbolname, node->leaf->text);
    } else {
        fprintf(fp, "\t%d [shape = rectangle, label=\"%s\"]\n", node->id, node->symbolname);
        printf("id=%d: symbolname=%s\n", node->id, node->symbolname);
    }
    
	if (node->nkids != 0) {
		for(i=0; i < node->nkids; i++){
        	print_graph_node(node->kids[i], fp);
    	}
    	fprintf(fp, "\t%d -> { ", node->id);
    	for(i=0;i < node->nkids; i++){
    		if(node->kids[i] != NULL) {fprintf(fp, "%d ", node->kids[i]->id);}
    	}
    	fprintf(fp, "}\n");
	}
	
	return 0;
}
