public class hello {
    int a;
    int i;
    public static void main(String argv[]) {
        int f = 13;
        char w = 'w';
        i = a * 4 + 2;
        a = 15;
        a++;
        a = i - 14 / 5 % 4;
        i = a + a;
    }
}
