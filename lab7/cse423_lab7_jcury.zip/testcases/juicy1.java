public class jstuff {
/*
	multi line
	comment
*/
// single line comment

boolean logicalValue;
// global scope variable declaration
int a, b, c, d6, x, y45, g0var, d6Var;
double dubVal;

void assignments() {
	a = 1;
	b = 2;
	c = c- 3;
}

void Operators() {
int w=0, x, y=0, z=0, q=0 ;
	x = -1;
	if (x < y && y <= z || z < q && q != x) {
	   x = y;
	   y = z;
	} else {
	   w = x + y * z / q - 4;
	   }
	logicalValue = w > 20;
}

void WhileStuff() {
int x;
   x = 0;
   for( ; x < 20; ){
	   x = d6;
	  return;
	  }
}

void RollTheDice() {
	d6Var = 6;
	y45 = d6Var;
}

void main() {
	RollTheDice();
	System.out.println("stuff and things\n");
	g0var = 2;
}

// class variable declaration
void MakeAPet() {
	// local scope variable declaration
   pet p= new pet();
   p.play();
   System.out.println("%d\n" + p.happy);
}

String stringOps() {
	String S1, S2;
	S1 = "One";
	S2 = S1 + "Two"; // uh oh
	return S2;
}

int []listOps()  {
	int [] L = new int[3];
	L[0] = 1; L[1] = 2; L[2] = 3;
	return L; // uh oh
}
}
