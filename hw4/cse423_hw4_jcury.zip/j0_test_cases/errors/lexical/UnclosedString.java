public class UnclosedString {
    public static void main(String args[]) {
		String num = "astringunclosed;
    }
}
