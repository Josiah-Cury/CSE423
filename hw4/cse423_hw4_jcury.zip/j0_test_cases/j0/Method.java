public class hello {
	void f() {
	   System.out.println("FFFFFFFF!");
	}

   int main(String argv[]) {
	   f();
      System.out.println("hello, jzero!");
   }
}
