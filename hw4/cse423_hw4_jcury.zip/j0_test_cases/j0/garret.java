public class HelloWorld{
  //checking single line
  /*multiple
  lines*/
  int a;
  char a;
  float a;
  boolean a;
  String a;
  int a;
  //short a;
  long a;
  double a;
  int num[];
  public static void main(){
    a = 5;
    a = 'a';
    a = 5 + 7;
    a = 583.6 * 32;
    for ( ; ; ) {
      b = 5;
    }
    if (a || b) {
      b = 'd';
    }
    if (x < 0) {}
    if (x) {} else if (x) {} else {}
  }
}
