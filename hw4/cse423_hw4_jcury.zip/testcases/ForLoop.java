public class hello {
    int a;
    int i;
   public static void main() {
      a = 15;
      for(i = 1; i < a; i++){
          System.out.println("juicy\t");
      }

   }
}
