

public class HelloWorld {
	public static void main(String[] args) {
		float t = 12.34;
		int i = 2;
		//char c = 'wowza';
		char d = 'd';
		System.out.println("Hello, World");
		switch (c) {
			case 1: case 2:
			   printf("1 or 2\n"); break;
			case 3: case 4:
			   printf("3 or 4\n"); break;
			default:
			   printf("some other value\n");
		}
	}
}

