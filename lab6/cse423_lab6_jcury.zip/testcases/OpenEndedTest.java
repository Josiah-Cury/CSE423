public class hello {
   public static void main() {
      System.out.println("hello, jzero!");
   }
}
