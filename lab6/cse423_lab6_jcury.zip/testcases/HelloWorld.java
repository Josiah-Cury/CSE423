public class hello {
    //this is a comment

    /* Multiline comment
    goes this long.*/

    int k = 1;
    char l, m, n, o;
     public static void main(String argv[]) {
      System.out.println("hello, jzero!");
      int f = 1;
      k = 'h';
      f = 1000000;
      if (k) {
          f = 2;
      } else if (j) {
          f = 3;
      } else if (l) {
          f = 4;
      } else {
          f = 5;
      }
      f++;
   }
}
