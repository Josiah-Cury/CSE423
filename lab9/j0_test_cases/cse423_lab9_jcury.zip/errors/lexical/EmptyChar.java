public class EmptyChar {
	char k = '';
    public static void main(String args[]) {
    }
}
