public class UnknownVar {
    public static void main(String args[]) {
		int num = 13x23b;
    }
}
