public class hello {
   public static void main(String argv[]) {
      System.out.println("hello, jzero!");
	  /* this is a regular comment */
	  /* here's a comment with /////// slashes */
	  /* this is a /* nested */ comment...should throw a lexical error */

   }
}
