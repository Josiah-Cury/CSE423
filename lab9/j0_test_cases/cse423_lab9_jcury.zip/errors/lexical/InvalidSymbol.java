public class InvalidSymbol {
    public static void main(String args[]) {
		int @num = 23;
    }
}
