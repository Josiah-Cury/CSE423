public class hello {
   public static void main(String argv[]) {
      SomethingUndeclared.out.println("hello, jzero!");
   }
}
