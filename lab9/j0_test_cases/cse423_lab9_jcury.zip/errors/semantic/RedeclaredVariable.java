public class hello {

	public static int poo(int a, char c, float f) {
		int j;
		int i = 1;
	}

	public char poo() {
		
	}

	public static void main(String argv[]) {
		int p;
		int q = 3;

		//should throw error for redeclaration
		int p;
	}
}
