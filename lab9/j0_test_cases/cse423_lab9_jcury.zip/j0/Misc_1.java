public class HelloWorld {
   public static void main(String args[]) {
      System.out.println("Hello, World");

	  xcc = 1 + 2 * 3 / 4 - 5;
   }
}
