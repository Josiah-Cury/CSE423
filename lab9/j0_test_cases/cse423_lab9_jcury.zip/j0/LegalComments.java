public class hello {
   public static void main(String argv[]) {
      System.out.println("hello, jzero!");
	  /* normal comment */
	  /* multiline
	  comment */
	  /******/
	  /*****hello*/
	  /*hello*****/
	  /*******hello******/
	  /******* hello ******/
	  /* * * * * hsdlfisjf * * * * */

	  // single line comments
	  //////////////super slashes
	  ///////////////// super duper slashes
	  /////////////////********** /* /*   */ */
	  // dslfdjfsldskfj //
	  //
	  //
	  //
	  //
	  //
	  /** super duper multi extra asterisk comment
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   *
	   */


	  /*******************************************
	   *
	   **************************************/
   }
}
