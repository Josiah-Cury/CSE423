public class Test {
	public static void main(String[] args) {
		float t = 12.34;
		int i = 12;
		int k = 0;
		//char c = 'wowza';
		char d = 'd';
		i++;
		k = i + 15;
	}
}
