public class hello {
   public static void main(String argv[]) {
      System.out.println("hello, jzero!");
   }
}
