public class Hello {
    //this is a comment

    /* Multiline comment
    goes this long.*/

    char l;
	int k = 0;
	//int k = 1;
    public static void main(String argv[]) {
      System.out.println("hello, jzero!");
	  InputStream.read();
      int f = 1;
      k = 'h';
      f = 1000000;
      if (k) {
          f = 2;
      } else if (k) {
          f = 3;
      } else if (l) {
          f = 4;
      } else {
          f = 5;
      }
      f++;
   }
}
