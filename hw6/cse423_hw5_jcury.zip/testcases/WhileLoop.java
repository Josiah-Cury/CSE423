public class hello {
	boolean a;
	boolean i;
	public static void main(String argv[]) {
		while(a && i || !a){
			System.out.println("juicy\t");
		}
	}
}
