public class jstuff {
/*
	multi line
	comment
*/
// single line comment

public static boolean logicalValue;
// global scope variable declaration
public static int a;
public static int b;
public static int c;
public static int d6;
public static int x;
public static int y45;
public static int g0var;
public static int d6Var;
public static double dubVal;

public static int assignments() {
	a = 1;
	b = 2;
	c = c- 3;
}

public static int Operators() {
int w=0;
int x;
int y=0;
int z=0;
int q=0 ;
	x = -1;
	if (x < y && y <= z || z < q && q != x) {
	   x = y;
	   y = z;
	} else {
	   w = x + y * z / q - 4;
	   }
	logicalValue = w > 20;
}

public static int WhileStuff() {
int x;
   x = 0;
   for( ; x < 20; ){
	   x = d6;
	  return;
	  }
}

public static int RollTheDice() {
	d6Var = 6;
	y45 = d6Var;
}

public static int main() {
	RollTheDice();
	System.out.println("stuff and things\n");
	g0var = 2;
}

// class variable declaration
// public static int MakeAPet() {
// 	// local scope variable declaration
//    pet p = new pet();
//    p.play();
//    System.out.println("%d\n" + p.happy);
// }

public static String stringOps() {
	String S1;
	String S2;
	S1 = "One";
	//S2 = S1 + "Two"; // uh oh
	return S2;
}

public static int []listOps()  {
	int [] L;
	L = new int[3];
	L[0] = 1; L[1] = 2; L[2] = 3;
	return L; // uh oh
}
}
