public class hello {
    int a;
    int i;
	char k = 0;
   public static void main() {
      a = 15;
      for(i = 1 + 1; i < a; k++){
          System.out.println("juicy\t");
      }

   }
}
