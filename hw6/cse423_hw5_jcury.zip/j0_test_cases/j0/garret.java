public class HelloWorld{
  //checking single line
  /*multiple
  lines*/
  int a;
  char b;
  float c;
  boolean d;
  String e;
  int f;
  //short a;
  long g;
  double h;
  int num[];
  int x;
  public static void main(){
    a = 5;
    a = 'a';
    a = 5 + 7;
    c = 583.6 * 32;
    for ( ; ; ) {
      a = 5;
    }
    if (d || b < a) {
      b = 'd';
    }
    if (x < 0) {}
    if (x) {} else if (x) {} else {}
  }
}
