public class hello {
    boolean a;
    int i;
   public static void main(String argv[]) {
      while(a && !a || a){
          System.out.println("juicy\t");
      }
   }
}
