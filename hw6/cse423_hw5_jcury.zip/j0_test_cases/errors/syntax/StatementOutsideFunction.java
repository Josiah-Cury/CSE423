public class test2 { static int f() {
   System.out.println("hello");
} }
// test2.java output [expect syntax error on line 5]
