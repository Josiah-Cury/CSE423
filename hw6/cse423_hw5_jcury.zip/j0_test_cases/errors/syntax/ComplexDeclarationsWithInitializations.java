public class hello {

	public static int foo() {
		int j;
		int i = 0;
	}

	public static int poo(int a, char c, float f) {
		int j, k = 0, l, m = 1, n;
		int i = 1;
	}

	public static void main(String argv[]) {
		int p;
		int q = 3;
	}
}
