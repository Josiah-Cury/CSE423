public class InvalidVarName {
    public static void main(String args[]) {
		String _8num = "astringunclosed";
    }
}
