public class hello {
   public static void main(String argv[]) {
      System.out.println("hello, jzero!");
	  /* this is a regular comment */
	  /* here's a comment with /////// slashes */
	  /******** this is another comment *******/
	  /*******/
	  /* now here's an unclosed comment

   }
}
